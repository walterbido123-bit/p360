# Autonomous QA / Correction Loop

```text
IMPLEMENTER
   ↓
QA GATE
   ├── PASS ─────────────→ NEXT GATE
   └── FAIL
        ↓ structured defect
OWNER AGENT
        ↓ patch + evidence
QA RE-RUN
        ├── PASS → NEXT GATE
        └── FAIL → repeat ≤ max_iterations
                     ↓
                  BLOCKED + escalate
```

## Defect contract
A defect must contain: stable ID, severity, owner agent, reproduction, expected, actual, evidence, affected files/routes, recommended verification and gate name.

## Stop conditions
- Never loop indefinitely.
- Default `max_iterations = 3` for the same defect class.
- Security/data-loss/release-blocking failures cannot be waived by the implementer.
- A skipped gate must record why it is unavailable or irrelevant.
