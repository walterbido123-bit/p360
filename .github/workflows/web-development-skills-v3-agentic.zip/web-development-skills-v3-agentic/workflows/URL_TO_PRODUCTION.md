# Workflow: URL → Audit → Figma → Code → GitHub → Tests → Deploy

## Gate 0 — Intake
Capture URL, ownership/authorization assumptions, goals, repo/design access, stack constraints and success metrics.

## Gate 1 — Baseline Audit
`21-audit-agent` records information architecture, page inventory, visual system, UX issues, SEO invariants, CWV baseline, accessibility issues and observable technology.
**Exit:** audit artifact + prioritized backlog + protected invariants.

## Gate 2 — Redesign Strategy
`22-redesign-agent` + `01-architecture-agent` decide preserve/change/remove, sitemap, templates, migration risks and target architecture.
**Exit:** approved architecture and redesign specification.

## Gate 3 — UX/UI/Figma
`02-ux-agent → 03-ui-agent → 04-design-system-agent`.
Create wireframes, responsive layouts, tokens, components and states in Figma when tooling is available.
**Exit:** implementation-ready nodes/components + responsive/state specification.

## Gate 4 — Implementation
`05-figma-code-agent` routes to `06/07`, plus `08/09/10/11/12/13` as needed.
Work in vertical slices. Every slice must build before the next large slice.
**Exit:** feature-complete preview build.

## Gate 5 — GitHub
`20-github-agent`: branch, atomic commits, PR, traceable description and required checks.
**Exit:** reviewable PR with no unexplained dirty state.

## Gate 6 — Automated Quality Loop
`18-qa-agent` executes lint → typecheck → unit → integration → E2E → a11y → build; `14/15/16/17` run specialist gates.
Failures are returned as JSON handoffs to the owning agent.
Maximum default correction cycles: 3 per defect class. After limit, mark BLOCKED and escalate with evidence.
**Exit:** all blocking gates PASS; skips require explicit reason.

## Gate 7 — Preview / Acceptance
Deploy preview. Verify critical journeys, responsive breakpoints, metadata, redirects, analytics/consent and error states.
**Exit:** release candidate accepted.

## Gate 8 — Production
`19-deploy-agent`: backup/migration readiness, production deploy, smoke tests, health checks and rollback readiness.
**Exit:** production verified + release record.

## Gate 9 — Post-deploy
Check logs, 4xx/5xx, indexing directives, CWV regression signals and critical conversions. Update project memory.
