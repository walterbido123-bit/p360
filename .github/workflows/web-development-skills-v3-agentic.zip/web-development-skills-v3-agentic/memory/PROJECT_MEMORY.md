# Project Memory

## Source of truth
- Brief:
- Production URL:
- Repository:
- Figma:
- Hosting:
- CMS:
- Analytics:

## Immutable constraints
-

## Current architecture
-

## Design decisions
-

## Technical decisions / ADR index
-

## Content and SEO invariants
-

## Open risks
-

## Current phase
-

## Last verified build
- Commit:
- Environment:
- Checks:
