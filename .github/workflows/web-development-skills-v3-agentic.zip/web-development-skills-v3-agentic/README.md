# Web Development Skills Pack — v3 Agentic

Sistema multiagente de 23 skills para ejecutar desarrollo web de extremo a extremo con estado compartido, contratos estructurados, quality gates y corrección iterativa.

## Arquitectura
- **Control plane:** `00-agentic-orchestrator`
- **Specialist agents:** 22 agentes con autoridad delimitada.
- **Project memory:** `memory/PROJECT_MEMORY.md`
- **Contracts:** JSON Schema para handoffs y estado.
- **Workflows:** URL→producción y QA correction loop.
- **Templates:** estado inicial y defecto estructurado.

## Workflow principal
`URL → Audit → Redesign/Architecture → UX/UI → Figma → Code → GitHub → QA loops → Preview → Deploy → Post-deploy`

## Reglas agentic
1. Un agente no invade silenciosamente el dominio de otro.
2. Todo cruce de dominio usa contrato de handoff.
3. El orquestador mantiene un DAG de dependencias.
4. Escrituras conflictivas se serializan.
5. Quality gates bloquean promoción de fase.
6. QA devuelve defectos al propietario; máximo 3 ciclos por defecto salvo configuración distinta.
7. Seguridad, pérdida de datos y fallos de release no se auto-excepcionan.
8. La memoria conserva decisiones durables; repo/Figma/URL siguen siendo fuentes de verdad operativas.
9. PASS exige evidencia.
10. Deploy exige rollback y smoke test.

## Archivos clave
- `contracts/agent-handoff.schema.json`
- `contracts/project-state.schema.json`
- `workflows/URL_TO_PRODUCTION.md`
- `workflows/QA_CORRECTION_LOOP.md`
- `templates/project-state.example.json`
- `templates/defect.example.json`

## Uso recomendado
Carga el orquestador como entrada. Dale URL/brief y, cuando existan, repo, Figma, hosting y criterios de éxito. El orquestador crea estado, selecciona agentes, ejecuta gates y mantiene trazabilidad hasta el resultado solicitado.

## Importante
El pack describe comportamiento agentic, pero las acciones reales dependen de las herramientas conectadas en el entorno: navegador, Figma, GitHub, shell, CI/CD, hosting, CMS, bases de datos y proveedores externos. Los agentes nunca deben simular una acción que no pudieron ejecutar.
